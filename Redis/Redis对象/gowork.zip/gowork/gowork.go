package gowork

import (
	"context"
	"errors"
	"fmt"
	"runtime/debug"
	"sync"
	"time"
	"unsafe"

	"git.woa.com/templegu/gowork/log"
	"git.woa.com/templegu/gowork/queue"
)

// Work gowork 核心结构定义
type Work struct {
	// ctx worker上下文环境
	ctx       context.Context
	ctxCancel context.CancelFunc
	// handlers handler注册信息     topic-handler映射
	handlers map[string]*Handler
	// taskListMap 任务队列
	taskListMap map[string]chan Task
	// handlerLock handler锁，负责handler注册，handler实例化等工作的原子性控制
	handlerLock sync.RWMutex
	// queueLock queue锁 负责队列注册，队列消息处理等工作的原子性控制
	queueLock sync.RWMutex
	// tasksChan 队列数据
	tasksChan map[string]chan Task
	// taskLock taskLock 任务锁，保证task通道消费的原子性
	taskLock sync.RWMutex
	// waitGroup 阻塞控制, 进程关闭时等待剩余任务结束
	waitGroup sync.WaitGroup
	// queueDriver 队列驱动程序
	queueDriver queue.Queue
	// 配置信息
	opts WorkOptions
	// rt 运行时状态信息
	rt Runtime
	// logger 日志记录器
	logger log.Logger
	logErr int
	// todo 中间件
	// middleware middleware
	// tw 时间轮组件指针
	tw unsafe.Pointer
}

// WorkOptions gowork 配置
type WorkOptions struct {
	// sleepy 监听休眠时间
	sleepy time.Duration
	// timer 监听超时
	timer time.Duration
	// defaultConcurrency 默认并发量， 阻塞运行 1
	defaultConcurrency int
}

// Runtime 运行时结构体
type Runtime struct {
	running bool
	// concurrency 并发控制通道 ,  控制单topic最多可同时运行多少handler
	concurrency map[string]chan struct{}
	// stats processStat
	stats map[string]*WorkStat
}

// WorkStat 当前状态
type WorkStat struct {
	LastMsgId        string
	PullTaskCnt      int64
	SuccessHandleCnt int64
	FailHandleCnt    int64
}

// HandlerBind handler注入
func (w *Work) HandlerBind(f func(task Task) TaskRunResult, topic string, args ...interface{}) (err error) {
	w.handlerLock.Lock()
	defer w.handlerLock.Unlock()
	_, ok := w.handlers[topic]
	if ok {
		return errors.New("the topic had been registered")
	}
	handler := &Handler{
		Call:           HandlerFunc(f),
		MaxConcurrency: w.opts.defaultConcurrency,
	}
	if len(args) > 0 {
		if maxConcurrency, ok := args[0].(int); ok {
			if maxConcurrency > 0 {
				handler.MaxConcurrency = maxConcurrency
			}
		}
	}
	w.handlers[topic] = handler
	return
}

// initHandlers 为handler创建并发控制队列
// 创建消息队列通道
func (w *Work) initHandlers() {
	for topic, handler := range w.handlers {
		// 用来控制handlers的并发数
		w.rt.concurrency[topic] = make(chan struct{}, handler.MaxConcurrency)
		for i := 0; i < handler.MaxConcurrency; i++ {
			// 入队初始空置任务
			w.rt.concurrency[topic] <- struct{}{}
		}
		// 存放消息数据的通道
		w.tasksChan[topic] = make(chan Task, 0)
		w.rt.stats[topic] = &WorkStat{}
	}
}

func (w *Work) runWork() {
	for topic := range w.handlers {
		go w.watchQueueTopic(topic)
	}
}

// watchQueueTopic 监听队列某个topic
func (w *Work) watchQueueTopic(topic string) {
	conChan := w.rt.concurrency[topic]
	timer := time.NewTimer(w.opts.timer)
	for {
		if !w.rt.running {
			return
		}
		select {
		case <-conChan:
			go w.fetchTask(topic)
		case <-timer.C:
			timer.Reset(w.opts.timer)
			continue
		}
	}
}

// fetchTask 监听Driver消息队列
func (w *Work) fetchTask(topic string) {
	var taskEnqueue bool
	w.waitGroup.Add(1)
	defer func() {
		w.waitGroup.Done()
		if !taskEnqueue {
			// 持续填充并发控制队列
			w.rt.concurrency[topic] <- struct{}{}
		}
	}()
	// 保证消息队列中间件线程池安全
	msg, err := w.queueDriver.Dequeue(w.ctx, topic)
	if err != nil && err != queue.ErrNil {
		// 异常处理
		w.Log(log.Error, err)
		time.Sleep(w.opts.sleepy)
		return
	}
	if err == queue.ErrNil {
		// 无消息处理
		time.Sleep(w.opts.sleepy)
		return
	}
	task, err := DecodeTaskJson(msg)
	if err != nil {
		w.Log(log.Error, "消息格式invalid", err)
		return
	} else if task.Topic != topic {
		w.Log(log.Error, "error topic task, msg: ["+msg+"] topic:"+topic)
		return
	}
	w.taskLock.RLock()
	taskChan := w.tasksChan[topic]
	w.taskLock.RUnlock()

	timer := time.NewTimer(w.opts.timer)
	for {
		select {
		case taskChan <- task:
			taskEnqueue = true
			w.addPullTaskCnt(topic)
			return
		case <-timer.C:
			timer.Reset(w.opts.timer)
			continue
		}
	}
}

// ProcessWork 任务执行调度
func (w *Work) ProcessWork() {
	for topic, taskChan := range w.tasksChan {
		go w.ProcessHandler(topic, taskChan)
	}
}

// ProcessHandler 监听taskChan
func (w *Work) ProcessHandler(_ string, taskChan <-chan Task) {
	// defer func() {
	//	if e := recover(); e != nil {
	//		w.logger.Error("process_task_panic", e)
	//		debug.PrintStack()
	//	}
	// }()
	timer := time.NewTimer(w.opts.timer)
	for {
		select {
		case task := <-taskChan:
			task.Ctx, _ = context.WithCancel(w.ctx)
			var expire uint64
			// 判断是否进行延时任务处理
			if task.ExpirationAt > 0 {
				if task.ExpirationAt >= getCurTimeUint64() {
					expire = task.ExpirationAt - getCurTimeUint64()
				} else {
					expire = 0
				}
				go w.afterFunc(task, time.Duration(expire)*time.Millisecond)
			} else if task.CronSpec != "" {
				go w.scheduleFunc(task)
			} else {
				go w.ProcessTask(task, false)
			}
		case <-timer.C:
			timer.Reset(w.opts.timer)
		}
	}
}

// ProcessTask 任务执行
func (w *Work) ProcessTask(task Task, sync bool) {
	w.Log(log.Info, "begin process task:", task)
	topic := task.Topic
	w.waitGroup.Add(1)
	defer w.processDefer(topic, sync, task)
	w.handlerLock.RLock()
	handler := w.handlers[topic]
	w.handlerLock.RUnlock()
	// todo 任务处理中间件：前置函数
	result := handler.Call.Run(task)
	w.updateLastMsgId(topic, task.Id)
	// 消费结果处理
	// 消息重放，ACK
	var isAck bool
	switch result.ResCode {
	case TaskRunSuccess:
		fallthrough
	case TaskRunFailedWithAck:
		isAck = true
	case TaskRunFailed:
		isAck = false
	}
	if isAck {
		ok, err := w.queueDriver.AckMsg(w.ctx, topic)
		if !ok && err != nil {
			w.logger.Warn("ack fail", err)
		}
		// 任务处理成功数+1
		w.addSuccessHandleCnt(topic)
	} else {
		// todo 消息重放
		w.addFailHandleCnt(topic)
	}
	if task.IsChain {
		fmt.Println("is chain, Continue ... ")
		w.ContinueTask(isAck, task, result)
	}
}

// ContinueTask 继续任务
func (w *Work) ContinueTask(isAck bool, task Task, result TaskRunResult) {
	var nextTask *Task
	if isAck {
		nextTask = task.OnSuccess
	} else {
		nextTask = task.OnFail
	}
	fmt.Println(nextTask)
	if nextTask == nil {
		return
	}
	// 参数传递（将上一任务执行结果传入下一任务）
	nextTask.LastRes = &result
	topic := nextTask.Topic
	if _, ok := w.handlers[topic]; !ok {
		w.logger.Error("the key " + topic + " unregistered")
	}
	w.taskLock.RLock()
	taskChan := w.tasksChan[topic]
	w.taskLock.RUnlock()
	taskChan <- task
	return
}

// EnqueueTaskChain 任务链入队
func (w *Work) EnqueueTaskChain(ctx context.Context, messages []map[string]string, args ...interface{}) error {
	chainLen := len(messages)
	if chainLen < 0 {
		return errors.New("messages slice cannot be empty")
	}
	for _, message := range messages {
		if len(message) <= 0 {
			return errors.New("message should be topic-message pair")
		}
	}
	task := &Task{}
	for key, value := range messages[0] {
		task = &Task{
			Id:      UUID(),
			Topic:   key,
			Message: value,
			IsChain: true,
		}
		break
	}
	headTask := task
	for i := 1; i < chainLen; i++ {
		for key, value := range messages[i] {
			task.OnSuccess = &Task{
				Id:      UUID(),
				Topic:   key,
				Message: value,
				IsChain: true,
			}
			break
		}
		task = task.OnSuccess
	}
	taskJson := JsonEncode(headTask)

	ok, err := w.queueDriver.Enqueue(ctx, headTask.Topic, taskJson, args)
	if !ok {
		return err
	}
	return nil
}

// Enqueue 单任务入队
func (w *Work) Enqueue(ctx context.Context, topic string, message string, args ...interface{}) error {
	// 入队场景不需要绑定检查
	// _, ok := w.handlers[topic]
	// if !ok {
	//	return errors.New("cannot find the handler by this topic! ")
	// }
	ok, err := w.queueDriver.Enqueue(ctx, topic, GenTaskJson(topic, message, TaskTypeNormal), args)
	if !ok {
		return err
	}
	return nil
}

// EnqueueExplicit 单任务入队 增加明确配置
func (w *Work) EnqueueExplicit(ctx context.Context, topic, message string, opts ...*taskOpt) error {
	task := NewTask(topic, message, TaskTypeNormal, opts...)
	encodedTask, err := task.Marshal()
	if err != nil {
		return err
	}
	ok, err := w.queueDriver.Enqueue(ctx, topic, encodedTask, nil)
	if !ok {
		return err
	}
	return nil
}

// AfterEnqueue 延时任务入队；expiration 经过多长时间后执行
func (w *Work) AfterEnqueue(ctx context.Context, topic string, message string, expiration time.Duration, args ...interface{}) error {
	expirationAt := getCurTimeUint64() + uint64(expiration/time.Millisecond)
	ok, err := w.queueDriver.Enqueue(ctx, topic, GenTaskJson(topic, message, TaskTypeAfter, expirationAt), args)
	if !ok {
		return err
	}
	return nil
}

// BatchEnqueue 批量入队
func (w *Work) BatchEnqueue(ctx context.Context, topic string, messages []string, args ...interface{}) error {
	taskJsonArr := make([]string, 0)
	for _, message := range messages {
		taskJsonArr = append(taskJsonArr, GenTaskJson(topic, message, TaskTypeNormal))
	}
	ok, err := w.queueDriver.BatchEnqueue(ctx, topic, taskJsonArr)
	if !ok {
		return err
	}
	return nil
}

// Schedule 新建周期任务
// cronSpec 和 cronCntMax 分别控制任务运行周期以及最大执行次数，cronCntMax 为 0 时无执行次数限制
// topic 仍需完成 handler 绑定
func (w *Work) Schedule(ctx context.Context,
	topic, message, cronSpec string, cronCntMax uint64, args ...interface{}) error {
	ok, err := w.queueDriver.Enqueue(ctx, topic, GenTaskJson(topic, message, TaskTypeSchedule, cronSpec, cronCntMax), args)
	if !ok {
		return err
	}
	return nil
}

// Log .
func (w *Work) Log(level int, v ...interface{}) {
	if w.logErr > level {
		return
	}
	switch level {
	case log.Debug:
		w.logger.Debug(v)
	case log.Info:
		w.logger.Info(v)
	case log.Warn:
		w.logger.Warn(v)
	case log.Error:
		w.logger.Error(v)
	}
}

// LogAndPrint .
func (w *Work) LogAndPrint(errLevel int, v ...interface{}) {
	w.Log(errLevel, v)
	fmt.Println(v...)
}

// GetLogger 获取 Work 绑定的 log.Logger 实例
func (w *Work) GetLogger() log.Logger {
	return w.logger
}

func (w *Work) processDefer(topic string, sync bool, task Task) {
	w.waitGroup.Done()
	// 保证handler的正常并发
	if sync == false {
		w.rt.concurrency[topic] <- struct{}{}
	}
	if err := recover(); err != nil {
		w.logger.Error("Process Task error : ", err)
		w.logger.Error(string(debug.Stack()))
		return
	}
	// 定时任务类型特殊逻辑
	task.CronCnt++
	if task.CronSpec != "" {
		if task.CronCntMax == 0 || task.CronCnt < task.CronCntMax {
			ok, err := w.queueDriver.Enqueue(context.Background(), topic, GenTaskJson(
				topic,
				task.Message,
				TaskTypeSchedule,
				task.CronSpec,
				task.CronCntMax,
				task.CronCnt))
			if !ok {
				w.logger.Error("cron task enqueue error : ", err)
				return
			}
		}
	}
}
