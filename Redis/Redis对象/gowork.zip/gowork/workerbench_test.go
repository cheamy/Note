package gowork

import (
	"context"
	"git.woa.com/templegu/gowork/log"
	"strconv"
	"testing"
	"time"
)

func BenchmarkWork_Enqueue(b *testing.B) {
	w := New()
	topic := "topic-bench-enqueue-test"
	//clearOldTestDataInList(topic)
	w.QueueDriverRegisterAlias("redis", redisConf)
	w.HandlerBind(testHandler, topic+"1")
	ctx := context.Background()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w.Enqueue(ctx, topic+"1", strconv.Itoa(i))
		//w.Enqueue(ctx, topic + "2", strconv.Itoa(i))
		//w.Enqueue(ctx, topic + "3", strconv.Itoa(i))
	}
	b.StopTimer()
}

func BenchmarkWork_Process(b *testing.B) {
	w := New()
	topic := "topic-bench-enqueue-test"
	w.QueueDriverRegisterAlias("redis", redisConf)
	w.HandlerBind(benchHandler, topic+"1", 100)
	w.Start()
	statInfo := w.GetStats()
	timer := time.NewTimer(5 * time.Second)
	var lastStats string
	for {
		select {
		case <-timer.C:
			temp := JsonEncode(statInfo[topic+"1"])
			if temp == lastStats {
				_ = w.Stop(3 * time.Second)
				return
			}
			lastStats = temp
			w.Log(log.Info, lastStats)
			//w.Log(log.Info, JsonEncode(statInfo[topic + "2"]))
			//w.Log(log.Info, JsonEncode(statInfo[topic + "3"]))
			timer.Reset(5 * time.Second)
			continue
		}
	}
	//25W   253,555
}

func benchHandler(task Task) TaskRunResult {
	return TaskRunResult{
		Id:      task.Id,
		ResCode: TaskRunSuccess,
		Message: task.Topic + "processed",
	}
}
