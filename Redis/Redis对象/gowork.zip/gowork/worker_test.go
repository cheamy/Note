package gowork

import (
	"context"
	"errors"
	"fmt"
	"git.woa.com/templegu/gowork/log"
	"git.woa.com/templegu/gowork/queue"
	"github.com/gomodule/redigo/redis"
	"github.com/stretchr/testify/assert"
	"testing"
	"time"
)

var kafkaConf = queue.KafkaConf{
	AddsProducer: []string{":9092"},
	AddsConsumer: []string{":9092"},
}

var pulsarConf = queue.PulsarConf{
	Endpoint:          "pulsar://localhost:6650",
	ConsumerGroupName: "test-group",
	AdminUrl:          "http://localhost:8080",
}

var redisConf = queue.RedisConf{
	Host:     "127.0.0.1",
	Password: "",
	Port:     "6379",
	Db:       0,
	Opts: queue.RedisOption{
		MaxIdle:        64,
		MaxActive:      256,
		IdleTimeout:    180 * time.Second,
		Wait:           false,
		ConnectTimeout: 1 * time.Second,
		ReadTimeout:    1 * time.Second,
		WriteTimeout:   1 * time.Second,
	},
}

var errRedisConf = queue.RedisConf{
	Host:     "127.0.0.1",
	Password: "1111",
	Port:     "6379",
	Db:       0,
	Opts: queue.RedisOption{
		MaxIdle:        64,
		MaxActive:      256,
		IdleTimeout:    180 * time.Second,
		Wait:           false,
		ConnectTimeout: 1 * time.Second,
		ReadTimeout:    1 * time.Second,
		WriteTimeout:   1 * time.Second,
	},
}

var tempRedisConn = &redis.Pool{
	Dial: func() (conn redis.Conn, e error) {
		addr := redisConf.Host + ":" + redisConf.Port
		conn, err := redis.Dial("tcp", addr,
			redis.DialConnectTimeout(redisConf.Opts.ConnectTimeout),
			redis.DialReadTimeout(redisConf.Opts.ReadTimeout),
			redis.DialWriteTimeout(redisConf.Opts.WriteTimeout))
		if err != nil {
			return nil, err
		}
		if redisConf.Password != "" {
			_, err = conn.Do("AUTH", redisConf.Password)
			if err != nil {
				return nil, err
			}
		}
		_, err = conn.Do("SELECT", redisConf.Db)
		if err != nil {
			return nil, err
		}
		return
	},
	MaxIdle:     redisConf.Opts.MaxIdle,
	MaxActive:   redisConf.Opts.MaxActive,
	IdleTimeout: redisConf.Opts.IdleTimeout,
	Wait:        redisConf.Opts.Wait,
}

func TestWorkerInit(t *testing.T) {
	// 初始化操作test
	w := New()
	ok, err := w.QueueDriverRegisterAlias("redis", redisConf)
	assert.Nil(t, err)
	assert.True(t, ok)
	ok, err = w.QueueDriverRegisterAlias("redis", errRedisConf)
	assert.EqualValues(t, errors.New("Do not set the driver repeatedly "), err)
	assert.False(t, ok)
	err = w.HandlerBind(testHandler, "topic-test", 12)
	assert.IsType(t, &Handler{Call: testHandler, MaxConcurrency: 12}, w.handlers["topic-test"])
	assert.Nil(t, err)

	// 消息正常入队test
	randStr1 := UUID()
	testMsg1 := `{"id" : "` + randStr1 + `"}`
	randStr2 := UUID()
	testMsg2 := `{"id" : "` + randStr2 + `"}`
	randStr3 := UUID()
	testMsg3 := `{"id" : "` + randStr3 + `"}`
	assert.IsType(t, string(""), randStr1)
	assert.IsType(t, string(""), randStr2)
	assert.IsType(t, string(""), randStr3)
	clearOldTestDataInList("topic-init-test")
	clearOldTestDataInList("topic-init-test2")
	clearOldTestDataInList("topic-init-test3")
	err = w.Enqueue(context.Background(), "topic-init-test", testMsg1)
	assert.Nil(t, err)
	err = w.Enqueue(context.Background(), "topic-init-test2", testMsg2)
	assert.Nil(t, err)
	err = w.Enqueue(context.Background(), "topic-init-test3", testMsg3)
	assert.Nil(t, err)
	task1, err := DecodeTaskJson(getRedisList("topic-init-test"))
	assert.Nil(t, err)
	task2, err := DecodeTaskJson(getRedisList("topic-init-test2"))
	assert.Nil(t, err)
	task3, err := DecodeTaskJson(getRedisList("topic-init-test3"))
	assert.Nil(t, err)
	assert.EqualValues(t, testMsg1, task1.Message)
	assert.EqualValues(t, testMsg2, task2.Message)
	assert.EqualValues(t, testMsg3, task3.Message)
	testChainMsg1 := map[string]string{"task-chain-test1": `{"id" : "159944853070542102"}`}
	testChainMsg2 := map[string]string{"task-chain-test2": `{"id" : "1599448530dffdfgas"}`}
	testChainMsg3 := map[string]string{"task-chain-test3": `{"id" : "1ergerwwe070542102"}`}
	err = w.EnqueueTaskChain(context.Background(), []map[string]string{testChainMsg1, testChainMsg2, testChainMsg3})
	assert.Nil(t, err)
}

func TestWork_HandlerBind(t *testing.T) {
	w := New()
	ok, err := w.QueueDriverRegisterAlias("redis", redisConf)
	assert.Nil(t, err)
	assert.True(t, ok)
	err = w.HandlerBind(testHandler, "topic-process-test", 10)
	assert.Nil(t, err)
	err = w.HandlerBind(testHandler, "topic-process-test", 10)
	assert.EqualValues(t, errors.New("the topic had been registered"), err)
}

func TestWork_BatchEnqueue(t *testing.T) {
	w := New()
	ok, err := w.QueueDriverRegisterAlias("redis", redisConf)
	assert.Nil(t, err)
	assert.True(t, ok)
	topic := "topic-test-batchenqueue"
	ok, err = w.QueueDriverRegisterAlias("redis", errRedisConf)
	err = w.HandlerBind(testHandler, topic, 12)
	// 消息正常入队test
	messages := make([]string, 0)
	for i := 0; i < 1000; i++ {
		randStr := UUID()
		testMsg := `{"id" : "` + randStr + `"}`
		messages = append(messages, testMsg)
	}
	err = w.BatchEnqueue(context.Background(), topic, messages)
	assert.Nil(t, err)
}

func TestWork_QueueDriverRegisterAlias(t *testing.T) {
	w := New()
	ok, err := w.QueueDriverRegisterAlias("redis")
	assert.EqualValues(t, errors.New("driver config error! "), err)
	assert.False(t, ok)
	ok, err = w.QueueDriverRegisterAlias("tttttt")
	assert.EqualValues(t, errors.New("no such driver yet "), err)
	assert.False(t, ok)
	ok, err = w.QueueDriverRegisterAlias("redis", redisConf)
	assert.Nil(t, err)
	assert.True(t, ok)
	ok, err = w.QueueDriverRegisterAlias("redis", errRedisConf)
	assert.EqualValues(t, errors.New("Do not set the driver repeatedly "), err)
	assert.False(t, ok)
}

func TestWork_QueueDriverRegister(t *testing.T) {
	// 初始化操作test
	w := New()
	q := queue.GetRedisQueue(redisConf)
	ok, err := w.QueueDriverRegister(q)
	assert.Nil(t, err)
	assert.True(t, ok)
	q = queue.GetRedisQueue(errRedisConf)
	ok, err = w.QueueDriverRegister(q)
	assert.EqualValues(t, errors.New("Do not set the driver repeatedly "), err)
	assert.False(t, ok)
	err = w.HandlerBind(testHandler, "topic-test", 12)
	assert.IsType(t, &Handler{Call: testHandler, MaxConcurrency: 12}, w.handlers["topic-test"])
	assert.Nil(t, err)
}

func TestWork_ProcessKafka(t *testing.T) {
	w := New()
	ok, err := w.QueueDriverRegisterAlias("kafka", kafkaConf)
	assert.Nil(t, err)
	assert.True(t, ok)
	err = w.HandlerBind(testHandler, "topic-process-test", 10)
	err = w.HandlerBind(testHandler, "topic-process-test2", 10)
	err = w.HandlerBind(testHandler, "topic-process-test3", 10)
	w.Start()
	//w.Enqueue(context.Background(), "topic-process-test", "msg1")
	//w.Enqueue(context.Background(), "topic-process-test2", "msg2")
	//w.Enqueue(context.Background(), "topic-process-test3", "msg3")
	//w.Enqueue(context.Background(), "topic-process-test3", "msg3")
	//w.Enqueue(context.Background(), "topic-process-test3", "msg3")
	time.Sleep(30 * time.Second)
	return
}

func TestWork_ProcessPulsar(t *testing.T) {
	w := New()
	ok, err := w.QueueDriverRegisterAlias("pulsar", pulsarConf)
	assert.Nil(t, err)
	assert.True(t, ok)
	err = w.HandlerBind(testHandler, "topic-process-test", 10)
	err = w.HandlerBind(testHandler, "topic-process-test2", 10)
	err = w.HandlerBind(testHandler, "topic-process-test3", 10)
	ctx := context.Background()
	w.Enqueue(ctx, "topic-process-test", "msg1")
	w.Enqueue(ctx, "topic-process-test2", "msg2")
	w.BatchEnqueue(ctx, "topic-process-test3", []string{"msg3", "msg3", "msg3"})
	assert.EqualValues(t, w.GetQueueLenByTopic("topic-process-test"), 1)
	assert.EqualValues(t, w.GetQueueLenByTopic("topic-process-test2"), 1)
	assert.EqualValues(t, w.GetQueueLenByTopic("topic-process-test3"), 3)
	w.Start()
	time.Sleep(5 * time.Second)
	assert.EqualValues(t, w.GetQueueLenByTopic("topic-process-test"), 0)
	assert.EqualValues(t, w.GetQueueLenByTopic("topic-process-test2"), 0)
	assert.EqualValues(t, w.GetQueueLenByTopic("topic-process-test3"), 0)
	return
}

func TestWork_Process(t *testing.T) {
	// 初始化操作test
	w := New()
	w.Start()
	ok, err := w.QueueDriverRegisterAlias("redis", redisConf)
	assert.Nil(t, err)
	assert.True(t, ok)
	err = w.HandlerBind(testHandler, "topic-process-test", 1)
	err = w.HandlerBind(testHandler, "topic-process-test2", 2)
	err = w.HandlerBind(testHandlerErr, "topic-process-test3", 3)
	err = w.HandlerBind(testHandler, "topic-process-test4", 1)
	err = w.HandlerBind(testHandler, "topic-process-test5", 1)
	assert.Nil(t, err)
	clearOldTestDataInList("topic-process-test")
	clearOldTestDataInList("topic-process-test2")
	clearOldTestDataInList("topic-process-test3")
	clearOldTestDataInList("topic-process-test4")
	clearOldTestDataInList("topic-process-test5")
	w.Enqueue(context.Background(), "topic-process-test", "msg1")
	w.Enqueue(context.Background(), "topic-process-test2", "msg2")
	w.Enqueue(context.Background(), "topic-process-test3", "msg3")
	w.AfterEnqueue(context.Background(), "topic-process-test4", "msg4 after!!", 4*time.Second)
	w.Schedule(context.Background(), "topic-process-test5", "schedule!!", "* * * * *", 0)

	// 启动测试
	w.Start()
	assert.EqualValues(t, true, w.rt.running)
	assert.IsType(t, make(chan struct{}, w.handlers["topic-process-test"].MaxConcurrency), w.rt.concurrency["topic-process-test"])
	time.Sleep(5 * time.Second)
	// 停止测试
	err = w.Stop(2 * time.Second)
	assert.EqualValues(t, false, w.rt.running)
	assert.Nil(t, err)
	ok, err = w.CloseQueueConn()
	assert.Nil(t, err)
	assert.True(t, ok)
	// 统计信息打印
	statInfo := w.GetStats()
	assert.EqualValues(t, 1, statInfo["topic-process-test"].PullTaskCnt)
	assert.EqualValues(t, 1, statInfo["topic-process-test"].SuccessHandleCnt)
	assert.EqualValues(t, 1, statInfo["topic-process-test2"].PullTaskCnt)
	assert.EqualValues(t, 1, statInfo["topic-process-test2"].SuccessHandleCnt)
	assert.EqualValues(t, 1, statInfo["topic-process-test3"].PullTaskCnt)
	assert.EqualValues(t, 1, statInfo["topic-process-test3"].FailHandleCnt)
	StatInfo2 := w.GetStats("topic-process-test", "topic-process-test2")
	assert.EqualValues(t, 1, StatInfo2["topic-process-test"].PullTaskCnt)
	assert.EqualValues(t, 1, StatInfo2["topic-process-test2"].PullTaskCnt)
}

func TestWork_Schedule(t *testing.T) {
	testTopic := "topic-process-test5"
	cronMax := uint64(3)
	w := New()
	ok, err := w.QueueDriverRegisterAlias("redis", redisConf)
	assert.Nil(t, err)
	assert.True(t, ok)
	err = w.HandlerBind(testHandler, testTopic, 1)
	w.Start()
	w.Schedule(context.Background(), testTopic, "schedule!!", "@every 2s", cronMax)
	time.Sleep(9 * time.Second)
	assert.EqualValues(t, int64(cronMax), w.GetStats(testTopic)[testTopic].SuccessHandleCnt)
}

func TestWork_Log(t *testing.T) {
	w := New()
	w.Log(-1, "test")
	w.Log(log.Debug, "test debug")
	w.Log(log.Info, "test info")
	w.Log(log.Warn, "test warn")
	w.Log(log.Error, "test error")
	w.LogAndPrint(log.Warn, "test log and print")
	logger := w.GetLogger()
	assert.IsType(t, log.GetDefaultLogger(), logger)
}

func testHandler(task Task) TaskRunResult {
	fmt.Println("message : ", task, "processing........")
	return TaskRunResult{
		Id:      task.Id,
		ResCode: TaskRunSuccess,
		Message: task.Topic + "processed",
	}
}

func testHandlerErr(task Task) TaskRunResult {
	fmt.Println("message : ", task, "processing........")
	return TaskRunResult{
		Id:      task.Id,
		ResCode: TaskRunFailed,
		Message: task.Topic + "processed",
	}
}

func clearOldTestDataInList(topic string) {
	conn := tempRedisConn.Get()
	defer conn.Close()
	_, _ = conn.Do("LTRIM", topic, 1, 0)
}

func getRedisList(topic string) string {
	conn := tempRedisConn.Get()
	defer conn.Close()
	msg, _ := redis.Strings(conn.Do("LRANGE", topic, 0, 1))
	return msg[0]
}
