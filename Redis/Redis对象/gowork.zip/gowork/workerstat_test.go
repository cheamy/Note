package gowork

import (
	"context"
	"github.com/stretchr/testify/assert"
	"strconv"
	"testing"
)

func TestWork_GetQueueLenByTopic(t *testing.T) {
	w := New()
	ok, err := w.QueueDriverRegisterAlias("local")
	assert.Nil(t, err)
	assert.True(t, ok)
	topic := "topic-stat-len-test"
	clearOldTestDataInList(topic)
	for i := 0; i < 10; i++ {
		w.Enqueue(context.Background(), topic, strconv.Itoa(i))
	}

	qLen := w.GetQueueLenByTopic(topic)
	assert.EqualValues(t, 10, qLen)
	qLen = w.GetQueueLenByTopic(topic + "x")
	assert.EqualValues(t, 0, qLen)
}
