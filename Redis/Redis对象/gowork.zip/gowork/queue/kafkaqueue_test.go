package queue

import (
	"context"
	"fmt"
	"testing"
)

const ProducerAdds = ":9092"
const ConsumerAdds = ":9092"
const TestTopic = "test_topic_1"

func TestGetKafkaQueue(t *testing.T) {
	config := KafkaConf{
		ProducerConfig: nil,
		ConsumerConfig: nil,
		AddsProducer:   []string{ProducerAdds},
		AddsConsumer:   []string{ConsumerAdds},
	}
	q := GetKafkaQueue(config)
	fmt.Println(q)
}

func TestKafkaQueue_Enqueue(t *testing.T) {
	config := KafkaConf{
		ProducerConfig: nil,
		ConsumerConfig: nil,
		AddsProducer:   []string{ProducerAdds},
		AddsConsumer:   []string{ConsumerAdds},
	}
	q := GetKafkaQueue(config)
	defer func() {
		q.producer.Close()
	}()
	for i := 0; i < 10000; i++ {
		q.Enqueue(context.Background(), "topic-process-test3", "topic-process-test")
		q.Enqueue(context.Background(), "topic-process-test2", "topic-process-test")
		q.Enqueue(context.Background(), "topic-process-test", "topic-process-test")
	}
}

func TestKafkaQueue_Dequeue(t *testing.T) {
	config := KafkaConf{
		ProducerConfig: nil,
		ConsumerConfig: nil,
		AddsProducer:   []string{ProducerAdds},
		AddsConsumer:   []string{ConsumerAdds},
	}
	q := GetKafkaQueue(config)
	defer func() {
		q.producer.Close()
		for _, consumer := range q.consumerGroup {
			consumer.Close()
		}
	}()
	msg, err := q.Dequeue(context.Background(), "topic-process-test3")
	fmt.Println(msg)
	fmt.Println(err)
}
