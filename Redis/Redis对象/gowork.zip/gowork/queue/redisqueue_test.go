package queue

import (
	"context"
	"errors"
	"fmt"
	"github.com/gomodule/redigo/redis"
	"github.com/stretchr/testify/assert"
	"testing"
)

var redisConf = RedisConf{
	Host:     "127.0.0.1",
	Password: "",
	Port:     "6379",
	Db:       0,
	Opts:     RedisOption{},
}

func TestGetRedisQueue(t *testing.T) {
	rq := GetRedisQueue(redisConf)
	clientInfo, _ := redis.String(rq.ins.Get().Do("INFO", "CLIENTS"))
	fmt.Println(clientInfo)
}

func TestRedisQueue_AckMsg(t *testing.T) {
	ctx := context.Background()
	key := "rq-test"
	rq := GetRedisQueue(redisConf)
	ok, err := rq.Enqueue(ctx, key, "1")
	assert.True(t, ok)
	assert.Nil(t, err)
	ok, err = rq.AckMsg(context.Background(), key)
	assert.True(t, ok)
	assert.Nil(t, err)
}

func TestRedisQueue_Close(t *testing.T) {
	rq := GetRedisQueue(redisConf)
	clientInfo, _ := redis.String(rq.ins.Get().Do("INFO", "CLIENTS"))
	fmt.Println(clientInfo)

	ok, err := rq.Close()
	assert.True(t, ok)
	assert.Nil(t, err)
	clientInfo, err = redis.String(rq.ins.Get().Do("INFO", "CLIENTS"))
	assert.EqualValues(t, errors.New("redigo: get on closed pool"), err)
}

func TestRedisQueue_Enqueue(t *testing.T) {
	ctx := context.Background()
	key := "rq-test-enqueue"
	rq := GetRedisQueue(redisConf)
	_, _ = rq.ins.Get().Do("LTRIM", key, 1, 0)
	ok, err := rq.Enqueue(ctx, key, "1")
	assert.True(t, ok)
	assert.Nil(t, err)
	qLen, err := rq.QueueLen(ctx, key)
	assert.Nil(t, err)
	assert.EqualValues(t, 1, qLen)
}

func TestRedisQueue_BatchEnqueue(t *testing.T) {
	ctx := context.Background()
	key := "rq-test-batchenqueue"
	rq := GetRedisQueue(redisConf)
	_, _ = rq.ins.Get().Do("LTRIM", key, 1, 0)
	ok, err := rq.BatchEnqueue(ctx, key, []string{"1", "2"})
	assert.True(t, ok)
	assert.Nil(t, err)
	qLen, err := rq.QueueLen(ctx, key)
	assert.Nil(t, err)
	assert.EqualValues(t, 2, qLen)
}

func TestRedisQueue_Dequeue(t *testing.T) {
	ctx := context.Background()
	key := "rq-test-dequeue"
	rq := GetRedisQueue(redisConf)
	_, _ = rq.ins.Get().Do("LTRIM", key, 1, 0)
	ok, err := rq.Enqueue(ctx, key, "1")
	assert.True(t, ok)
	assert.Nil(t, err)
	msg, err := rq.Dequeue(ctx, key)
	assert.Nil(t, err)
	assert.EqualValues(t, "1", msg)
}
