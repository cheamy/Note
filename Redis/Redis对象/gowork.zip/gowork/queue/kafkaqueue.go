package queue

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"time"

	"github.com/Shopify/sarama"
	cluster "github.com/bsm/sarama-cluster"
)

// KafkaQueue kafka 队列
type KafkaQueue struct {
	producer      sarama.AsyncProducer
	consumerGroup map[string]*cluster.Consumer
	conf          KafkaConf
	lock          sync.RWMutex
}

// KafkaConf kafka 配置
type KafkaConf struct {
	ProducerConfig *sarama.Config
	ConsumerConfig *cluster.Config
	AddsProducer   []string
	AddsConsumer   []string
	ConsumerName   string
}

//	Enqueue(ctx context.Context, key string, message string, args ...interface{}) (isOk bool, err error)
//	Dequeue(ctx context.Context, key string) (message string, err error)
//	AckMsg(ctx context.Context, key string) (ok bool, err error)
//	Close() (ok bool, err error)

// Enqueue 入队
func (kq *KafkaQueue) Enqueue(ctx context.Context, key string, message string, args ...interface{}) (isOk bool, err error) {
	kafkaMsg := &sarama.ProducerMessage{Topic: key, Value: sarama.StringEncoder(message)}
	kq.producer.Input() <- kafkaMsg
	// return true, nil
	timer := time.NewTimer(time.Duration(time.Millisecond * 10000))
	for {
		select {
		case <-kq.producer.Successes():
			return true, nil
		case err := <-kq.producer.Errors():
			return false, err
		case <-timer.C:
			return false, errors.New("enqueue timeout")
		}
	}
}

// BatchEnqueue 批量入队
func (kq *KafkaQueue) BatchEnqueue(ctx context.Context, key string, message []string, args ...interface{}) (isOk bool, err error) {
	return true, nil
}

// Dequeue 出队
func (kq *KafkaQueue) Dequeue(ctx context.Context, key string) (message string, err error) {
	kq.lock.Lock()
	consumer := kq.consumerGroup[key]
	if consumer == nil {
		consumerClient, err := cluster.NewClient(kq.conf.AddsConsumer, kq.conf.ConsumerConfig)
		if err != nil {
			fmt.Printf("init consumer failed : %v \n", err)
			return "", err
		}
		kq.consumerGroup[key], err = cluster.NewConsumerFromClient(consumerClient, kq.GetConsumerName(key), []string{key})
		if err != nil {
			fmt.Println("topic: " + key + "no msg")
			return "", err
		}
	}
	kq.lock.Unlock()
	timer := time.NewTimer(time.Millisecond * 10000)
	for {
		select {
		case msg, ok := <-kq.consumerGroup[key].Messages():
			if ok {
				kq.consumerGroup[key].MarkOffset(msg, "")
				return string(msg.Value), nil
			}
		case err, ok := <-kq.consumerGroup[key].Errors():
			if ok {
				return "", err
			}
		case ntf, ok := <-kq.consumerGroup[key].Notifications():
			if ok {
				fmt.Printf("consumer notification: %v", ntf)
			}
		case <-timer.C:
			return "", ErrNil
		}
	}
}

// GetConsumerName 获取消费者名
func (kq *KafkaQueue) GetConsumerName(key string) string {
	if len(kq.conf.ConsumerName) == 0 {
		return key
	}

	return kq.conf.ConsumerName
}

func (kq *KafkaQueue) AckMsg(ctx context.Context, key string) (ok bool, err error) {
	return true, nil
}

// Close 关闭消费和生产者
func (kq *KafkaQueue) Close() (ok bool, err error) {
	ok = true
	defer func() {
		if err != nil {
			ok = false
		}
	}()

	for _, consumer := range kq.consumerGroup {
		err = consumer.Close()
	}
	err = kq.producer.Close()
	return
}

// QueueLen 队列长度
func (kq *KafkaQueue) QueueLen(ctx context.Context, key string) (ql int, err error) {
	kq.consumerGroup[key].CommitOffsets()
	return 0, nil
}

// GetKafkaQueue 初始化驱动producer， consumer
func GetKafkaQueue(kc KafkaConf) (queue *KafkaQueue) {
	kc.formatOption()
	producer, err := sarama.NewAsyncProducer(kc.AddsProducer, kc.ProducerConfig)
	if err != nil {
		fmt.Printf("init producer failed : %v \n", err)
		panic(err)
	}
	queue = new(KafkaQueue)
	queue.producer = producer
	queue.consumerGroup = make(map[string]*cluster.Consumer)
	queue.conf = kc
	return
}

// InitKafkaQueue 根据 KafkaConfig 初始化 KafkaQueue 失败时抛出错误
func InitKafkaQueue(kc KafkaConf) (*KafkaQueue, error) {
	kc.formatOption()
	producer, err := sarama.NewAsyncProducer(kc.AddsProducer, kc.ProducerConfig)
	if err != nil {
		return nil, err
	}
	queue := &KafkaQueue{
		producer:      producer,
		consumerGroup: make(map[string]*cluster.Consumer),
		conf:          kc,
	}
	return queue, nil
}

// formatOption 初始化默认配置
func (kc *KafkaConf) formatOption() {
	if kc.ProducerConfig == nil {
		kc.ProducerConfig = sarama.NewConfig()
		kc.ProducerConfig.Producer.Return.Successes = true
		kc.ProducerConfig.Producer.Return.Errors = true
		kc.ProducerConfig.Producer.RequiredAcks = sarama.WaitForLocal
		kc.ProducerConfig.Producer.Partitioner = sarama.NewRandomPartitioner
	}

	if kc.ConsumerConfig == nil {
		kc.ConsumerConfig = cluster.NewConfig()
		kc.ConsumerConfig.Consumer.Return.Errors = true
		kc.ConsumerConfig.Group.Return.Notifications = true
		// 消费者rebalance分区策略 - 默认
		kc.ConsumerConfig.Consumer.Group.Rebalance.Strategy = sarama.BalanceStrategyRange
		// 重启后从最新偏移量开始消费
		kc.ConsumerConfig.Consumer.Offsets.Initial = sarama.OffsetOldest
		kc.ConsumerConfig.Consumer.Offsets.CommitInterval = time.Second
	}
}
