package queue

import (
	"context"
	"errors"
	"sync"
)

var (
	lock  sync.RWMutex
	queue map[string][]string
)

type LocalQueue struct {
}

func init() {
	queue = make(map[string][]string)
}

func (lq *LocalQueue) Enqueue(ctx context.Context, key string, message string, args ...interface{}) (isOk bool, err error) {
	lock.Lock()
	defer lock.Unlock()

	if _, ok := queue[key]; !ok {
		queue[key] = []string{}
	}
	queue[key] = append(queue[key], message)

	return true, nil
}

func (kq *LocalQueue) BatchEnqueue(ctx context.Context, key string, message []string, args ...interface{}) (isOk bool, err error) {
	return true, nil
}

func (lq *LocalQueue) Dequeue(ctx context.Context, key string) (message string, err error) {
	if _, ok := queue[key]; !ok {
		return "", errors.New("no such queue :" + key)
	}
	if len(queue[key]) > 0 {
		message = queue[key][0]
		queue[key] = queue[key][1:]
	} else {
		return "", ErrNil
	}
	return
}

func (lq *LocalQueue) AckMsg(ctx context.Context, key string) (ok bool, err error) {
	if _, ok := queue[key]; !ok {
		return false, ErrNil
	}
	if len(queue[key]) > 0 {
		queue[key] = queue[key][1:]
	}

	return true, nil
}

func (lq *LocalQueue) Close() (ok bool, err error) {
	return true, nil
}

func (lq *LocalQueue) QueueLen(ctx context.Context, key string) (ql int, err error) {
	if _, ok := queue[key]; !ok {
		return 0, errors.New("no such topic - " + key)
	}
	ql = len(queue[key])
	return
}
