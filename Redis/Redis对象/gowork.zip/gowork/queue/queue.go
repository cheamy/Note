package queue

import (
	"context"
	"errors"
)

var (
	ErrNil              = errors.New("return nil")
	ErrFuncNotSupported = errors.New("unsupported function")
)

// Queue 消息队列
type Queue interface {
	Enqueue(ctx context.Context, key string, message string, args ...interface{}) (isOk bool, err error)
	BatchEnqueue(ctx context.Context, key string, messages []string, args ...interface{}) (isOk bool, err error)
	Dequeue(ctx context.Context, key string) (message string, err error)
	AckMsg(ctx context.Context, key string) (ok bool, err error)
	Close() (ok bool, err error)
	QueueLen(ctx context.Context, key string) (ql int, err error)
}

type QueuesTopic struct {
	Queue  Queue
	Topics []string
}
