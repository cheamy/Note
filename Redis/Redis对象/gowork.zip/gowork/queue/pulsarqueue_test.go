package queue

import (
	"context"
	"testing"
)

const PULSAR_TEST_KEY = "my-partitioned-topic"
const PULSAR_TEST_BODY = "test-body"

var PULSAR_QUEUE, _ = GetPulsarQueue(PulsarConf{
	Endpoint:          "pulsar://localhost:6650",
	ConsumerGroupName: "test-group",
	AdminUrl:          "http://localhost:8080",
})

func TestGetPulsarQueue(t *testing.T) {
	var err error
	_, err = GetPulsarQueue(PulsarConf{
		Endpoint:          "pulsar://localhost:6650",
		ConsumerGroupName: "test-group",
		AdminUrl:          "http://localhost:8080",
	})
	if err != nil {
		t.Error("get pulsar queue err: " + err.Error())
		return
	}
	_, err = GetPulsarQueue(PulsarConf{
		Endpoint:          "pulsar://localhost:6650",
		ConsumerGroupName: "test-group",
	})
	if err != nil {
		t.Error("get pulsar queue err: " + err.Error())
		return
	}
	_, err = GetPulsarQueue(PulsarConf{
		ConsumerGroupName: "test-group",
	})
	if err == nil {
		t.Error("get pulsar no endpoint queue err: ")
		return
	}
	_, err = GetPulsarQueue(PulsarConf{
		Endpoint: "pulsar://localhost:6650",
	})
	if err == nil {
		t.Error("get pulsar no consumer queue err: ")
		return
	}
}

func TestPulsarQueue_EnqueueDequeue(t *testing.T) {
	ctx := context.Background()
	_, err := PULSAR_QUEUE.Enqueue(ctx, PULSAR_TEST_KEY, PULSAR_TEST_BODY)
	if err != nil {
		t.Error("enqueue err: " + err.Error())
	}
	msg, err := PULSAR_QUEUE.Dequeue(ctx, PULSAR_TEST_KEY)
	if err != nil {
		t.Error("dequeue err: " + err.Error())
		return
	}
	if msg != PULSAR_TEST_BODY {
		t.Error("unmatched body: " + msg)
		return
	}
}

func TestPulsarQueue_AckMsg(t *testing.T) {
	ctx := context.Background()
	_, err := PULSAR_QUEUE.AckMsg(ctx, PULSAR_TEST_KEY)
	if err != ErrFuncNotSupported {
		t.Error("unexpected error: " + err.Error())
	}
}

func TestPulsarQueue_BatchEnqueue(t *testing.T) {
	ctx := context.Background()
	lengthBefore, _ := PULSAR_QUEUE.QueueLen(ctx, PULSAR_TEST_KEY)
	_, err := PULSAR_QUEUE.BatchEnqueue(ctx, PULSAR_TEST_KEY, []string{PULSAR_TEST_BODY, PULSAR_TEST_BODY, PULSAR_TEST_BODY})
	if err != nil {
		t.Error("batch enqueue err: " + err.Error())
		return
	}
	lengthAfter, _ := PULSAR_QUEUE.QueueLen(ctx, PULSAR_TEST_KEY)
	if lengthAfter-lengthBefore != 3 {
		t.Error("batch enqueue num err")
	}

}

func TestPulsarQueue_Close(t *testing.T) {
	ctx := context.Background()
	_, err := PULSAR_QUEUE.Close()
	if err != nil {
		t.Error("npe close error: " + err.Error())
		return
	}
	PULSAR_QUEUE.Enqueue(ctx, PULSAR_TEST_KEY, PULSAR_TEST_BODY)
	PULSAR_QUEUE.Dequeue(ctx, PULSAR_TEST_KEY)
	_, err = PULSAR_QUEUE.Close()
	if err != nil {
		t.Error("normal close error: " + err.Error())
	}
}

func TestPulsarQueue_QueueLen(t *testing.T) {
	ctx := context.Background()
	_, err := PULSAR_QUEUE.QueueLen(ctx, PULSAR_TEST_KEY+"not-exists")
	if err != ErrPulsarConsumerGroupNotRegister {
		t.Error("not register len error: " + err.Error())
		return
	}
	_, err = PULSAR_QUEUE.QueueLen(ctx, PULSAR_TEST_KEY)
	if err != nil {
		t.Error("normal len error: " + err.Error())
	}
}
