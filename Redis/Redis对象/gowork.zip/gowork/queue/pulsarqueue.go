package queue

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/apache/pulsar-client-go/pulsar"
	"io/ioutil"
	"net/http"
	"strings"
	"sync"
	"time"
)

const PULSAR_DEFAULT_TENANT = "public"
const PULSAR_DEFAULT_NAMESPACE = "default"

var (
	ErrPulsarInvalidConf              = errors.New("invalid pulsar conf")
	ErrPulsarConsumerGroupNotRegister = errors.New("consumer group not register")
)

type PulsarConf struct {
	Endpoint          string //broker接入点，必填
	ConsumerGroupName string //消费者组名，必填
	Tenant            string //租户名
	Namespace         string //命名空间
	AdminUrl          string //管理端url，通过http访问
}

type PulsarQueue struct {
	clientConf        pulsar.ClientOptions
	consumerGroupName string //这里使用最简单的round-robin消费共享模式，不考虑复杂消费模型，必填
	prefix            string //租户名+命名空间的资源前缀
	adminUrl          string //管理端url，通过http访问
	pulsarClient      pulsar.Client
	pulsarConsumerMap map[string]pulsar.Consumer
	pulsarProducerMap map[string]pulsar.Producer
	lock              sync.RWMutex
}

func GetPulsarQueue(conf PulsarConf) (*PulsarQueue, error) {
	q := new(PulsarQueue)
	if conf.Endpoint == "" {
		return nil, ErrPulsarInvalidConf
	}
	if conf.ConsumerGroupName == "" {
		return nil, ErrPulsarInvalidConf
	}
	if conf.Tenant == "" {
		conf.Tenant = PULSAR_DEFAULT_TENANT
	}
	if conf.Namespace == "" {
		conf.Namespace = PULSAR_DEFAULT_NAMESPACE
	}
	q.clientConf = pulsar.ClientOptions{
		URL: conf.Endpoint,
	}
	q.consumerGroupName = conf.ConsumerGroupName
	q.prefix = conf.Tenant + "/" + conf.Namespace
	q.adminUrl = conf.AdminUrl

	err := q.guaranteeClient()
	return q, err
}

type PulsarAdminTopicStatResponse struct {
	Subscriptions map[string]struct {
		MsgBacklog int `json:"msgBacklog"`
	} `json:"subscriptions"`
}

func (q *PulsarQueue) guaranteeClient() (err error) {
	if q.pulsarClient == nil {
		q.lock.Lock()
		defer q.lock.Unlock()
		if q.pulsarClient == nil {
			q.pulsarClient, err = pulsar.NewClient(q.clientConf)
			if err != nil {
				return err
			}
		}
	}
	return nil
}

func (q *PulsarQueue) guaranteeProducer(key string) (err error) {
	err = q.guaranteeClient()
	if err != nil {
		return err
	}
	if q.pulsarProducerMap == nil {
		q.lock.Lock()
		if q.pulsarProducerMap == nil {
			producer, err := q.pulsarClient.CreateProducer(pulsar.ProducerOptions{
				Topic:           strings.Join([]string{q.prefix, key}, "/"),
				DisableBatching: true,
			})
			if err != nil {
				return err
			}
			q.pulsarProducerMap = map[string]pulsar.Producer{
				key: producer,
			}
		}
		q.lock.Unlock()
	}
	if _, exists := q.pulsarProducerMap[key]; !exists {
		q.lock.Lock()
		if _, exists := q.pulsarProducerMap[key]; !exists {
			producer, err := q.pulsarClient.CreateProducer(pulsar.ProducerOptions{
				Topic:           strings.Join([]string{q.prefix, key}, "/"),
				DisableBatching: true,
			})
			if err != nil {
				return err
			}
			q.pulsarProducerMap[key] = producer
		}
		q.lock.Unlock()
	}
	return nil
}

func (q *PulsarQueue) guaranteeConsumer(key string) (err error) {
	err = q.guaranteeClient()
	if err != nil {
		return err
	}
	if q.pulsarConsumerMap == nil {
		q.lock.Lock()
		if q.pulsarConsumerMap == nil {
			consumer, err := q.pulsarClient.Subscribe(pulsar.ConsumerOptions{
				Topic:            strings.Join([]string{q.prefix, key}, "/"),
				SubscriptionName: q.consumerGroupName,
				Type:             pulsar.Shared, //这里只是用最简单的round-robin模式，高级模式自己实现吧
			})
			if err != nil {
				return err
			}
			q.pulsarConsumerMap = map[string]pulsar.Consumer{
				key: consumer,
			}
		}
		q.lock.Unlock()
	}
	if _, exists := q.pulsarConsumerMap[key]; !exists {
		q.lock.Lock()
		if _, exists := q.pulsarConsumerMap[key]; !exists {
			consumer, err := q.pulsarClient.Subscribe(pulsar.ConsumerOptions{
				Topic:            strings.Join([]string{q.prefix, key}, "/"),
				SubscriptionName: q.consumerGroupName,
				Type:             pulsar.Shared, //这里只是用最简单的round-robin模式，高级模式自己实现吧
			})
			if err != nil {
				return err
			}
			q.pulsarConsumerMap[key] = consumer
		}
		q.lock.Unlock()
	}
	return nil
}

func (q *PulsarQueue) Enqueue(ctx context.Context, key string, message string, args ...interface{}) (isOk bool, err error) {
	err = q.guaranteeProducer(key)
	if err != nil {
		return false, err
	}
	_, err = q.pulsarProducerMap[key].Send(ctx, &pulsar.ProducerMessage{
		Payload: []byte(message),
		Key:     key,
		Properties: map[string]string{
			"ts":              fmt.Sprintf("%v", time.Now().UnixNano()/1e6),
			"written_by":      "gowork",
			"gowork-task-key": key,
		},
	})
	if err != nil {
		return false, err
	}
	return true, nil
}

func (q *PulsarQueue) BatchEnqueue(ctx context.Context, key string, messages []string, args ...interface{}) (isOk bool, err error) {
	err = q.guaranteeProducer(key)
	if err != nil {
		return false, err
	}
	for i := 0; i < len(messages); i++ {
		q.pulsarProducerMap[key].SendAsync(ctx, &pulsar.ProducerMessage{
			Payload: []byte(messages[i]),
			Key:     key,
			Properties: map[string]string{
				"ts":              fmt.Sprintf("%v", time.Now().UnixNano()/1e6),
				"written_by":      "gowork",
				"gowork-task-key": key,
			},
		}, func(id pulsar.MessageID, message *pulsar.ProducerMessage, singleErr error) {
			err = singleErr
		})
		if err != nil {
			return false, err
		}
	}
	err = q.pulsarProducerMap[key].Flush()
	if err != nil {
		return false, err
	}
	return true, nil
}

func (q *PulsarQueue) Dequeue(ctx context.Context, key string) (message string, err error) {
	err = q.guaranteeConsumer(key)
	if err != nil {
		return "", err
	}
	var msg pulsar.Message
	msg, err = q.pulsarConsumerMap[key].Receive(ctx)
	if err != nil {
		return "", err
	}
	q.pulsarConsumerMap[key].Ack(msg) //todo 当前gowork模型无法实现exactly-once的ack，只能强制ack
	return string(msg.Payload()), err
}

func (q *PulsarQueue) AckMsg(ctx context.Context, key string) (ok bool, err error) {
	return true, ErrFuncNotSupported
}

func (q *PulsarQueue) Close() (ok bool, err error) {
	if q.pulsarProducerMap != nil {
		for _, producer := range q.pulsarProducerMap {
			producer.Close()
		}
	}
	if q.pulsarConsumerMap != nil {
		for _, consumer := range q.pulsarConsumerMap {
			consumer.Close()
		}
	}
	if q.pulsarClient != nil {
		q.pulsarClient.Close()
	}
	return true, nil
}

func (q *PulsarQueue) QueueLen(ctx context.Context, key string) (ql int, err error) {
	err = q.guaranteeClient()
	if err != nil {
		return 0, err
	}
	if q.adminUrl == "" {
		return 0, ErrFuncNotSupported
	}
	url := strings.Join([]string{q.adminUrl, "admin/v2/persistent", q.prefix, key, "stats"}, "/")
	resp, err := http.Get(url)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	var stats PulsarAdminTopicStatResponse
	err = json.Unmarshal(body, &stats)
	if err != nil {
		return 0, err
	}
	if stats.Subscriptions == nil {
		return 0, ErrPulsarConsumerGroupNotRegister
	}
	if _, exists := stats.Subscriptions[q.consumerGroupName]; !exists {
		return 0, ErrPulsarConsumerGroupNotRegister
	}
	return stats.Subscriptions[q.consumerGroupName].MsgBacklog, nil
}
