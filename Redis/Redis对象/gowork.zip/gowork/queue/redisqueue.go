package queue

import (
	"context"
	"errors"
	"github.com/gomodule/redigo/redis"
	"io"
	"strings"
	"sync"
	"time"
)

var (
	mu sync.RWMutex
)

type RedisQueue struct {
	ins *redis.Pool
}
type RedisConf struct {
	Host     string
	Password string
	Port     string
	Db       int
	Opts     RedisOption
}

type RedisOption struct {
	MaxIdle        int
	MaxActive      int
	IdleTimeout    time.Duration
	Wait           bool
	ConnectTimeout time.Duration
	ReadTimeout    time.Duration
	WriteTimeout   time.Duration
}

func (rq *RedisQueue) Enqueue(ctx context.Context, key string, message string, args ...interface{}) (isOk bool, err error) {
	_, err = rq.ReDo("RPUSH", key, message)
	if err != nil {
		return false, err
	}
	return true, err
}

func (rq *RedisQueue) Dequeue(ctx context.Context, key string) (message string, err error) {
	message, err = redis.String(rq.ReDo("LPOP", key))
	if err == redis.ErrNil {
		return "", ErrNil
	}
	return
}

func (rq *RedisQueue) BatchEnqueue(ctx context.Context, key string, messages []string, args ...interface{}) (isOk bool, err error) {
	//redis暂时不要延迟和优先级
	if len(messages) == 0 {
		return false, errors.New("messages is empty")
	}
	_, err = rq.ReDo("RPush", formatBatchMessage(key, messages)...)
	if err != nil {
		return false, err
	}
	return true, err
}

func (rq *RedisQueue) AckMsg(ctx context.Context, key string) (ok bool, err error) {
	return true, nil
}

func (rq *RedisQueue) Close() (ok bool, err error) {
	err = rq.ins.Close()
	return true, err
}

func (rq *RedisQueue) QueueLen(ctx context.Context, key string) (ql int, err error) {
	ql, err = redis.Int(rq.ReDo("LLEN", key))
	return
}

func (rq *RedisQueue) ReDo(command string, args ...interface{}) (rep interface{}, err error) {
	conn := rq.ins.Get()
	defer conn.Close()
	rep, err = conn.Do(command, args...)
	if IsConnError(err) {
		var maxRetry = 3
		conn, err = rq.ins.Dial()
		for index := 0; index < maxRetry; index++ {
			if conn == nil && index+1 > maxRetry {
				return rep, err
			}
			if conn == nil {
				conn, err = rq.ins.Dial()
			}
			if err != nil {
				continue
			}
			rep, err = conn.Do(command, args...)
			if IsConnError(err) {
				conn, err = rq.ins.Dial()
			} else {
				return rep, err
			}
		}
		return "", errors.New("redis error")
	}
	return
}

func IsConnError(err error) bool {
	var needNewConn bool
	if err == nil {
		return false
	}
	if err == io.EOF {
		needNewConn = true
	}
	if strings.Contains(err.Error(), "use of closed network connection") {
		needNewConn = true
	}
	if strings.Contains(err.Error(), "connect: connection refused") {
		needNewConn = true
	}
	return needNewConn
}

func GetRedisQueue(conf RedisConf) *RedisQueue {
	conf.formatOption()
	mu.Lock()
	defer mu.Unlock()
	redisIns := &redis.Pool{
		Dial: func() (conn redis.Conn, e error) {
			addr := conf.Host + ":" + conf.Port
			conn, err := redis.Dial("tcp", addr,
				redis.DialConnectTimeout(conf.Opts.ConnectTimeout),
				redis.DialReadTimeout(conf.Opts.ReadTimeout),
				redis.DialWriteTimeout(conf.Opts.WriteTimeout))
			if err != nil {
				return nil, err
			}
			if conf.Password != "" {
				_, err = conn.Do("AUTH", conf.Password)
				if err != nil {
					return nil, err
				}
			}
			_, err = conn.Do("SELECT", conf.Db)
			if err != nil {
				return nil, err
			}
			return
		},
		MaxIdle:     conf.Opts.MaxIdle,
		MaxActive:   conf.Opts.MaxActive,
		IdleTimeout: conf.Opts.IdleTimeout,
		Wait:        conf.Opts.Wait,
	}
	rq := &RedisQueue{ins: redisIns}
	return rq
}

func (rc *RedisConf) formatOption() {
	if rc.Opts.MaxIdle <= 0 {
		rc.Opts.MaxIdle = 64
	}
	if rc.Opts.MaxActive <= 0 {
		rc.Opts.MaxActive = 256
	}
	if rc.Opts.IdleTimeout <= 0 {
		rc.Opts.IdleTimeout = 180 * time.Second
	}
	if rc.Opts.ConnectTimeout <= 0 {
		rc.Opts.ConnectTimeout = 1 * time.Second
	}
	if rc.Opts.ReadTimeout <= 0 {
		rc.Opts.ReadTimeout = 1 * time.Second
	}
	if rc.Opts.WriteTimeout <= 0 {
		rc.Opts.WriteTimeout = 1 * time.Second
	}
}

func formatBatchMessage(key string, msg []string) []interface{} {
	res := make([]interface{}, 0)
	res = append(res, key)
	for _, v := range msg {
		res = append(res, v)
	}
	return res
}
