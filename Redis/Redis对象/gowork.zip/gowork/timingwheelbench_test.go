package gowork

import (
	"fmt"
	"testing"
)

func BenchmarkWork_AfterEnqueue(b *testing.B) {
	for i := 0; i < b.N; i++ {
		fmt.Println(111)
	}
}
