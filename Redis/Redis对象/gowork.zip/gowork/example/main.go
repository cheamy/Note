package main

import (
	"context"
	"fmt"
	"git.woa.com/templegu/gowork"
	"git.woa.com/templegu/gowork/log"
	"git.woa.com/templegu/gowork/queue"
	"os"
	"os/signal"
	"time"
)

const TopicExample = "topic-example"

func main() {

	pidFile := "./worker-example.pid"
	writePidFile(pidFile)

	signalChan := make(chan os.Signal, 1)

	w := gowork.New()
	_ = w.SetLogger(log.GetDefaultLogger())
	// 两种注册方法
	//q := new(queue.LocalQueue)
	//ok, err := j.QueueDriverRegister(q)
	// 队列驱动注册 （别名）

	//type RedisConf struct {
	//	Host     string
	//	Password string
	//	Port     int
	//	Db       int
	//	Opts     RedisOption
	//}
	//
	//type RedisOption struct {
	//	MaxIdle        int
	//	MaxActive      int
	//	IdleTimeout    time.Duration
	//	Wait           bool
	//	ConnectTimeout time.Duration
	//	ReadTimeout    time.Duration
	//	WriteTimeout   time.Duration
	//}
	redisConf := queue.RedisConf{
		Host:     "127.0.0.1",
		Password: "",
		Port:     "6379",
		Db:       0,
		Opts:     queue.RedisOption{},
	}
	ok, err := w.QueueDriverRegisterAlias("redis", redisConf)

	// 注册kafka driver方式如下
	//kc := queue.KafkaConf{
	//	AddsConsumer: []string{"127.0.0.1:9092"},
	//	AddsProducer: []string{"127.0.0.1:9092"},
	//}
	//ok, err := w.QueueDriverRegisterAlias("kafka", kc)

	if !ok {
		fmt.Println(err)
		return
	}
	// workerFunc 注册
	_ = w.HandlerBind(testWorker, TopicExample, 10)
	_ = w.HandlerBind(testWorker, "task-chain-test1", 10)

	pushSomeData(w, TopicExample)
	w.Start()

	time.Sleep(time.Microsecond * 1000)

	statInfo := make(map[string]*gowork.WorkStat)
	statInfo = w.GetStats(TopicExample)
	fmt.Println("statistics : " + gowork.JsonEncode(statInfo))

	// 信号量监听
	signal.Notify(signalChan, os.Interrupt, os.Kill)
	<-signalChan
}

func pushSomeData(w *gowork.Work, topic string) {
	testMsg := `{"id" : "159944853070542102"}`
	err := w.Enqueue(context.Background(), topic, testMsg)
	err = w.AfterEnqueue(context.Background(), topic, testMsg, 10 * time.Second)
	if err != nil {
		fmt.Println(err)
	}
}

func testWorker(task gowork.Task) gowork.TaskRunResult {
	fmt.Println("message : ", task, "processing........")
	return gowork.TaskRunResult{}
}

func writePidFile(pidFile string) {
	file, _ := os.Create(pidFile)
	defer file.Close()

	pid := os.Getpid()
	file.WriteString(fmt.Sprintf("%d\n", pid))

	return
}
