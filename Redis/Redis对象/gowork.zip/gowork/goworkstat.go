package gowork

import (
	"errors"
	"sync"
	"sync/atomic"

	"git.woa.com/templegu/gowork/log"
)

// GetQueueLen 获取剩余队列长度
func (w *Work) GetQueueLen() map[string]int {
	qlMap := make(map[string]int, 0)
	for topic, _ := range w.rt.stats {
		ql, err := w.queueDriver.QueueLen(w.ctx, topic)
		if err != nil {
			w.Log(log.Error, err)
		}
		qlMap[topic] = ql
	}

	return qlMap
}

// GetQueueLenByTopic 获取剩余队列长度
func (w *Work) GetQueueLenByTopic(topic string) int {
	ql, err := w.queueDriver.QueueLen(w.ctx, topic)
	if err != nil {
		w.Log(log.Error, err)
	}
	return ql
}

// GetStats 批量获取运行时统计信息
func (w *Work) GetStats(args ...string) map[string]*WorkStat {
	if len(args) == 0 {
		return w.rt.stats
	}
	stats := make(map[string]*WorkStat)
	for _, topic := range args {
		stats[topic] = w.rt.stats[topic]
	}
	return stats
}

// 添加任务拉取数
func (w *Work) addPullTaskCnt(topic string) {
	if _, ok := w.rt.stats[topic]; ok {
		atomic.AddInt64(&w.rt.stats[topic].PullTaskCnt, 1)
		return
	}
	w.Log(log.Error, errors.New("addPullTaskCnt: topic err"))
}

// 添加任务handle成功数
func (w *Work) addSuccessHandleCnt(topic string) {
	if _, ok := w.rt.stats[topic]; ok {
		atomic.AddInt64(&w.rt.stats[topic].SuccessHandleCnt, 1)
		return
	}
	w.Log(log.Error, errors.New("addSuccessHandleCnt: topic err"))
}

// 添加任务handle成功数
func (w *Work) addFailHandleCnt(topic string) {
	if _, ok := w.rt.stats[topic]; ok {
		atomic.AddInt64(&w.rt.stats[topic].FailHandleCnt, 1)
		return
	}
	w.Log(log.Error, errors.New("addFailHandleCnt: topic err"))
}

// 更新最新拉取消息id
func (w *Work) updateLastMsgId(topic string, msgId string) {
	var mu sync.RWMutex
	if _, ok := w.rt.stats[topic]; ok {
		mu.Lock()
		w.rt.stats[topic].LastMsgId = msgId
		mu.Unlock()
		return
	}
	w.Log(log.Error, errors.New("updateLastMsgId: topic err"))
}
