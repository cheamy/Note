package gowork

// Handler 定义执行方法、并发控制数
type Handler struct {
	Call HandlerFunc
	MaxConcurrency int
}

// HandlerFunc 定义handler 方法类型
type HandlerFunc func(task Task) TaskRunResult

// Run 注册方法时统一封装run方法为单一出口
func (w HandlerFunc) Run(task Task) TaskRunResult {
	return w(task)
}

