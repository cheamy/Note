# gowork
gowork 是一个用golang语言实现的后台队列任务调度扩展包，内置多种队列驱动，并支持模块注入。
### 开始
获取mod包
```
go get git.woa.com/templegu/gowork
```

运行example
```
go build -o ./example/example ./example/main.go
./example/example
```
### 特性
- 平滑启停
- 超时处理
- 拥塞控制
- 模块注入
- 多驱动
- 事件处理 (doing)
- 消息重放（doing）
- stat（doing）
- 延时消息（todo）
- 消息优先级控制（todo）
- web UI（todo）

### 支持内置队列Driver
- local （同步，异步无法通过chan通信）
- redis
- kafka （doing）
- amazon SQS (todo)
- aliMns (todo)


Example usage:
```
package main

import (
	"context"
	"fmt"
	"git.woa.com/templegu/gowork"
	"time"
)

const TopicExample = "topic-example"

func main() {
	stop := make(chan int, 0)

	w := gowork.New()
	// 两种注册方法
	//q := new(queue.LocalQueue)
	//ok, err := j.QueueDriverRegister(q)
	// 队列驱动注册 （别名）
	ok, err := w.QueueDriverRegisterAlias("local")
	if !ok {
		fmt.Println(err)
		return
	}
	// workerFunc 注册
	_ = w.HandlerBind(testWorker, TopicExample)
	pushSomeData(w, TopicExample)
	w.Start()

	time.Sleep(time.Microsecond * 1000)

	statInfo := make(map[string]*gowork.WorkStat)
	statInfo = w.GetStats(TopicExample)
	fmt.Println(gowork.JsonEncode(statInfo))
	<-stop
}

func pushSomeData(w *gowork.Work, topic string) {
	testMsg := `{"id" : "159944853070542102"}`
	_ = w.Enqueue(context.Background(), topic, testMsg)
}

func testWorker(task gowork.Task) gowork.TaskRunResult {
	fmt.Println(1)
	fmt.Println(task , "执行中........")
	return gowork.TaskRunResult{}
}
```

## 队列相关
gowork支持两种队列驱动加载的方式，分别是自定义驱动注册和内置驱动注册。内置驱动注册仅需alias和配置参数即可完成驱动注册。而自定义驱动需继承模块定义的interface
```
// 1、内置驱动别名注册
type RedisConf struct {
	Host     string
	Password string
	Port     int
	Db       int
	Opts     RedisOption
}

type RedisOption struct {
	MaxIdle        int
	MaxActive      int
	IdleTimeout    time.Duration
	Wait           bool
	ConnectTimeout time.Duration
	ReadTimeout    time.Duration
	WriteTimeout   time.Duration
}

redisConf := queue.RedisConf{
		Host:     "127.0.0.1",
		//Password: "xxxxxxxx",
		Port:     6379,
		//Db:       0,
		Opts:     queue.RedisOption{},
	}
ok, err := w.QueueDriverRegisterAlias("redis", redisConf)

```
外部驱动interface类型：
```
// 2、外部驱动注入

type Queue interface {
	Enqueue(ctx context.Context, key string, message string, args ...interface{}) (isOk bool, err error)
	Dequeue(ctx context.Context, key string) (message string, err error)
	AckMsg(ctx context.Context, key string) (ok bool, err error)
	Close() (ok bool, err error)
	QueueLen(ctx context.Context, key string) (ql int, err error)
	//BatchEnqueue(ctx context.Context, key string, messages []string, args ...interface{}) (isOk bool, err error)
}

q := new(queue.LocalQueue)
ok, err := j.QueueDriverRegister(q)
```

### 延时队列
配合使用[timingwheel][1]包实现，任务执行阶段会判断时间并加入时间轮响应分片，待指定时间后执行任务，该队列同样受topic并发控制，
若分布较散可考虑调大相应的concurrency。

在任务入队时指定是否为延时方法，例：
```
	_ := w.AfterEnqueue(context.Background(), topic, testMsg, 10 * time.Second)
```


### 周期任务

在任务入队时指定是否为周期方法，cronSpec和cronCntMax分别控制任务运行周期以及最大执行次数，cronCntMax为0时无执行次数限制，topic仍需完成handler绑定
例：
```	
    testTopic := "topic-process-test5"
    cronMax := uint64(3)
    w := New()
    ok, err := w.QueueDriverRegisterAlias("redis", redisConf)
    err = w.HandlerBind(testHandler, testTopic, 1)
    w.Start()
    //cronSpec:Second | Minute | Hour | Dom | Month | DowOptional | Descriptor
    w.Schedule(context.Background(), testTopic, "schedule!!", "@every 2s", cronMax)
    time.Sleep(9 * time.Second)
```
组件使用[cron][1]进行规范式解析，估使用时可直接参照编写任务周期规范式。而调度部分则同afterFunc一致。



## option配置
- **SetOptSleepy** : 设置任务消费睡眠时间
- **SetOptTimer** : 设置队列监听超时timer
- **SetOptDefaultConcurrency** : 设置每个队列的最高并发handler数量
- **SetOptLogErrLv** ： 设置log最低等级

## logger注入
默认logger为logrus包，如果需要使用其他logger或者自定义日志规范，只需要实现实例化logger并注入即可。
```
type Logger interface {
	Debug(v ...interface{})
	Info(v ...interface{})
	Warn(v ...interface{})
	Error(v ...interface{})
}

_  = w.SetLogger(log.GetDefaultLogger())

```

## stat 统计
目前记录了如下计数信息，并且根据topic放入不同的map中：
```
type Runtime struct {
	running bool
	// 并发控制通道 ,  控制单topic最多可同时运行多少handler
	concurrency map[string]chan struct{}
	//processStat
	stats map[string]*WorkStat
	// processStat
}

type WorkStat struct {
    //最后执行任务ID 
	LastMsgId        string
	//拉取任务数量
	PullTaskCnt      int
	//执行成功任务数
	SuccessHandleCnt int
	//执行失败任务数
	FailHandleCnt    int
}
```
提供以下两个方法分别获取计数信息和队列长度：

```
// 获取剩余队列长度
func (w *Work) GetQueueLenByTopic(topic string) int {
	ql, err := w.queueDriver.QueueLen(w.ctx, topic)
	if err != nil {
		w.Log(log.Error, err)
	}
	return ql
}

// 批量获取运行时统计信息
func (w *Work) GetStats(args ...string) map[string]*WorkStat {
	if len(args) == 0 {
		return w.rt.stats
	}
	stats := make(map[string]*WorkStat)
	for _, topic := range args {
		stats[topic] = w.rt.stats[topic]
	}
	return stats
}
```

### 测试
- worker主流程单元测试
- 内置redis驱动单元测试
- BenchmarkWork_Enqueue-8   	   23637	     46674 ns/op
- 测试覆盖率：
![go_test_with_cover.png](./go_test_with_cover.png)

[1]: https://git.woa.com/templegu/timingwheel/
[2]: https://github.com/robfig/cron