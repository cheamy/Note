package gowork

import (
	"github.com/stretchr/testify/assert"
	"testing"
	"time"
)

func TestTimingwheel_afterFunc(t *testing.T) {

	w := New()
	ok, err := w.QueueDriverRegisterAlias("redis", redisConf)
	assert.Nil(t, err)
	assert.True(t, ok)
	err = w.HandlerBind(testHandler, "topic-process-test", 10)
	assert.Nil(t, err)
	w.initHandlers()
	for i := 0; i < 10; i++ {
		t.Run("", func(t *testing.T) {
			<- w.rt.concurrency["topic-process-test"]
			w.afterFunc(Task{
				Id:      "1",
				Topic:   "topic-process-test",
				Message: "aaaaaaaaaaaaaaaaa",
			}, 5*time.Second)
		})
	}
	time.Sleep(10 * time.Second)
}

func TestTimingwheel_scheduleFunc(t *testing.T) {
	w := New()
	ok, err := w.QueueDriverRegisterAlias("redis", redisConf)
	assert.Nil(t, err)
	assert.True(t, ok)
	err = w.HandlerBind(testHandler, "testtopic", 10)
	assert.Nil(t, err)
	w.initHandlers()
	task := Task{
		Id:           "1",
		Topic:        "testtopic",
		Message:      "123",
		Ctx:          nil,
		ExpirationAt: 0,
		IsChain:      false,
		LastRes:      nil,
		OnSuccess:    nil,
		OnFail:       nil,
		CronSpec:     "@every 5s",     //或者用 "0 0 20 1 * ?"
	}
	<- w.rt.concurrency["testtopic"]
	w.scheduleFunc(task)

	time.Sleep(6 * time.Second)
}
