package gowork

import (
	"errors"
	"git.woa.com/templegu/gowork/log"
	"github.com/stretchr/testify/assert"
	"testing"
	"time"
)

func TestWork_SetOptTimer(t *testing.T) {
	w := New()
	ok, err := w.SetOptTimer(99 * time.Microsecond)
	assert.EqualValues(t, 99*time.Microsecond, w.opts.timer)
	assert.Nil(t, err)
	assert.True(t, ok)
}

func TestWork_SetOptSleepy(t *testing.T) {
	w := New()
	ok, err := w.SetOptSleepy(100 * time.Microsecond)
	assert.EqualValues(t, 100*time.Microsecond, w.opts.sleepy)
	assert.Nil(t, err)
	assert.True(t, ok)
}

func TestWork_SetOptLogErrLv(t *testing.T) {
	w := New()
	ok, err := w.SetOptLogErrLv(log.Debug)
	assert.Nil(t, err)
	assert.True(t, ok)
	assert.EqualValues(t, log.Debug, w.logErr)
	ok, err = w.SetOptLogErrLv(-1)
	assert.False(t, ok)
	assert.EqualValues(t, errors.New("errLevel should be between Debug and Error"), err)
}

func TestWork_SetLogger(t *testing.T) {
	w := New()
	err := w.SetLogger(log.GetDefaultLogger())
	assert.IsType(t, log.GetDefaultLogger(), w.logger)
	assert.Nil(t, err)
	w.rt.running = true
	err = w.SetLogger(log.GetDefaultLogger())
	assert.EqualValues(t, errors.New("please stop the worker! "), err)
}

func TestWork_SetOptDefaultConcurrency(t *testing.T) {
	w := New()
	ok, err := w.SetOptDefaultConcurrency(20)
	assert.Nil(t, err)
	assert.True(t, ok)
	assert.EqualValues(t, 20, w.opts.defaultConcurrency)
	ok, err = w.SetOptDefaultConcurrency(-1)
	assert.False(t, ok)
	assert.EqualValues(t, errors.New("concurrency must be a positive integer"), err)
}
