package gowork

import (
	"git.woa.com/templegu/gowork/log"
	"git.woa.com/templegu/timingwheel"
	"github.com/robfig/cron"
	"runtime/debug"
	"sync/atomic"
	"time"
	"unsafe"
)

func (w *Work) afterFunc(task Task, expire time.Duration) {
	defer func() {
		w.rt.concurrency[task.Topic] <- struct{}{}
		if err := recover(); err != nil {
			w.logger.Error("Process Task error : ", err)
			w.logger.Error(string(debug.Stack()))
		}
	}()
	timingWheel := atomic.LoadPointer(&w.tw)
	if timingWheel == nil {
		atomic.CompareAndSwapPointer(
			&w.tw,
			nil,
			unsafe.Pointer(timingwheel.NewTimingWheel(time.Second, 1<<2)),
		)
		timingWheel = atomic.LoadPointer(&w.tw)
		(*timingwheel.TimingWheel)(timingWheel).Start()
	}
	(*timingwheel.TimingWheel)(timingWheel).AfterFunc(expire, func() {
		w.ProcessTask(task, true)
	})
}

// scheduleFunc spec:Second | Minute | Hour | Dom | Month | DowOptional | Descriptor
func (w *Work) scheduleFunc(task Task) {
	schedule, err := cron.Parse(task.CronSpec)
	if err != nil {
		w.Log(log.Error, err)
		return
	}
	nextTimeUint64 := uint64(schedule.Next(time.Now()).UnixNano() / int64(time.Millisecond))
	expire := nextTimeUint64 - getCurTimeUint64()
	if expire < 0 {
		expire = 0
	}
	w.afterFunc(task, time.Duration(expire)*time.Millisecond)
}
