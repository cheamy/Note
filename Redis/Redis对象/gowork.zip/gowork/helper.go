package gowork

import (
	"encoding/json"
	"github.com/google/uuid"
	"time"
)

func UUID() string {
	u, _ := uuid.NewRandom()
	return u.String()
}

func DecodeTaskJson(tJson string) (t Task, err error) {
	err = json.Unmarshal([]byte(tJson), &t)
	return
}

func JsonEncode(v interface{}) string {
	bytes, _ := json.Marshal(v)
	jsonStr := string(bytes)
	return jsonStr
}

func getCurTimeUint64() uint64 {
	return uint64(time.Now().UnixNano() / int64(time.Millisecond))
}