package gowork

import (
	"context"
	"errors"
	"sync"
	"sync/atomic"
	"time"

	"git.woa.com/templegu/gowork/log"
	"git.woa.com/templegu/timingwheel"
)

// New 实例化 goworker
func New() *Work {
	wCtx, wCtxCancel := context.WithCancel(context.Background())
	w := &Work{
		ctx:         wCtx,
		ctxCancel:   wCtxCancel,
		handlers:    make(map[string]*Handler),
		tasksChan:   make(map[string]chan Task),
		handlerLock: sync.RWMutex{},
		queueLock:   sync.RWMutex{},
		taskLock:    sync.RWMutex{},
		opts: WorkOptions{
			sleepy:             time.Millisecond * 20,
			timer:              time.Millisecond * 40,
			defaultConcurrency: 10,
		},
		waitGroup: sync.WaitGroup{},
		rt: Runtime{
			running:     false,
			concurrency: make(map[string]chan struct{}),
			stats:       make(map[string]*WorkStat),
		},
		logErr: log.Debug,
		logger: log.GetDefaultLogger(),
	}
	return w
}

// Start gowork 运行
func (w *Work) Start() {
	if w.queueDriver == nil {
		w.Log(log.Error, errors.New("please Register an queue driver！"))
		return
	}
	// step 1 初始化
	if w.rt.running == true {
		return
	}
	w.rt.running = true
	w.initHandlers()
	// step 2 起监听
	w.runWork()
	// step 3 起消费
	w.ProcessWork()
}

// Stop 暂停
func (w *Work) Stop(args ...time.Duration) error {
	w.Log(log.Info, "worker stopping")
	if w.rt.running == false {
		return nil
	}
	w.rt.running = false
	w.ctxCancel()
	timingWheel := atomic.LoadPointer(&w.tw)
	if timingWheel != nil {
		(*timingwheel.TimingWheel)(timingWheel).Stop()
	}

	if len(args) > 0 {
		waitTime := args[0]
		if waitTime <= 0 {
			waitTime = 10 * time.Second
		}
		c := make(chan struct{})

		go func() {
			defer close(c)
			w.waitGroup.Wait()
		}()
		select {
		case <-c:
			w.Log(log.Info, "worker stopped")
			return nil
		case <-time.After(waitTime):
			return errors.New("等待任务处理超时.... ")
		}
	}
	w.Log(log.Info, "worker stopped")
	return nil
}

// CloseQueueConn 关闭 Work.queueDriver 连接
func (w *Work) CloseQueueConn() (bool, error) {
	return w.queueDriver.Close()
}
