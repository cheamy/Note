package gowork

import (
	"context"
	"encoding/json"
)

const (
	// TaskRunSuccess 成功，默认会触发ack
	TaskRunSuccess = iota
	// TaskRunFailed 失败，默认不会触发ack 说明：没有触发ack，如果queue服务支持，会进行消息重放
	TaskRunFailed
	// TaskRunFailedWithAck 失败，会触发ack
	TaskRunFailedWithAck
)

const (
	TaskTypeNormal = iota
	TaskTypeAfter
	TaskTypeSchedule
)

// Task gowork 任务定义
type Task struct {
	Id          string `json:"id"`
	TraceID     string `json:"trace_id"`
	Topic       string `json:"topic"`
	Message     string `json:"message"`
	SafeMessage []byte `json:"safe_message"`
	Ctx         context.Context
	// expirationAt 任务执行具体时间戳 ms
	ExpirationAt uint64 `json:"expiration_at"`
	// cronSpec
	CronSpec   string `json:"cron_spec,omitempty"`
	CronCnt    uint64 `json:"cron_cnt,omitempty"`
	CronCntMax uint64 `json:"cron_cnt_max,omitempty"`
	// 任务链相关
	IsChain   bool           `json:"is_chain,booleans"`
	LastRes   *TaskRunResult `json:"last_res,omitempty"`
	OnSuccess *Task          `json:"on_success,omitempty"`
	OnFail    *Task          `json:"on_fail,omitempty"`

	binarySafe bool
}

// TaskRunResult 任务执行结果
type TaskRunResult struct {
	Id      string
	ResCode int
	Message string
}

// GenTaskJson task to json
func GenTaskJson(topic string, message string, taskType int8, args ...interface{}) string {
	task := &Task{
		Id:           UUID(),
		Topic:        topic,
		Message:      message,
		IsChain:      false,
		ExpirationAt: 0,
		CronCnt:      0,
	}

	switch taskType {
	case TaskTypeNormal:
	case TaskTypeAfter:
		if len(args) > 0 {
			task.ExpirationAt = args[0].(uint64)
		}
	case TaskTypeSchedule:
		if len(args) > 0 {
			task.CronSpec = args[0].(string)
		}
		if len(args) > 1 {
			task.CronCntMax = args[1].(uint64)
		}
		if len(args) > 2 {
			task.CronCnt = args[2].(uint64)
		}
	}
	// bytes, _ := json.Marshal(task)
	taskJson := JsonEncode(task)
	return taskJson
}

// NewTask 新建 Task 实例
func NewTask(topic, message string, taskType int8, opts ...*taskOpt) *Task {
	task := &Task{
		Id:    UUID(),
		Topic: topic,
	}
	for _, opt := range opts {
		opt.apply(task)
	}
	if !task.binarySafe {
		task.SafeMessage = []byte(message)
	} else {
		task.Message = message
	}
	return task
}

type taskOpt struct {
	apply func(task *Task)
}

var (
	// WithExpirationAt 设置 ExpirationAt
	WithExpirationAt = func(expirationAt uint64) *taskOpt {
		return &taskOpt{apply: func(task *Task) {
			task.ExpirationAt = expirationAt
		}}
	}
	// WithCronCnt 设置 CronCnt
	WithCronCnt = func(cronCnt uint64) *taskOpt {
		return &taskOpt{apply: func(task *Task) {
			task.CronCnt = cronCnt
		}}
	}
	// WithCronCntMax 设置 CronCntMax
	WithCronCntMax = func(cronCntMax uint64) *taskOpt {
		return &taskOpt{apply: func(task *Task) {
			task.CronCntMax = cronCntMax
		}}
	}
	// WithCronSpec 设置 CronSpec
	WithCronSpec = func(cronSpec string) *taskOpt {
		return &taskOpt{apply: func(task *Task) {
			task.CronSpec = cronSpec
		}}
	}
	// WithBinarySafe 设置 binarySafe 为 true 以 []byte 类型写入 message
	WithBinarySafe = func() *taskOpt {
		return &taskOpt{apply: func(task *Task) {
			task.binarySafe = true
		}}
	}
	// WithTraceID 设置 traceID
	WithTraceID = func(traceID string) *taskOpt {
		return &taskOpt{apply: func(task *Task) {
			task.TraceID = traceID
		}}
	}
)

// Marshal .
func (t *Task) Marshal() (string, error) {
	taskJson, err := json.Marshal(t)
	if err != nil {
		return "", err
	}
	return string(taskJson), nil
}

// BinaryMessage 返回 Message / SafeMessage 到[]byte
func (t *Task) BinaryMessage() []byte {
	if t.binarySafe {
		return t.SafeMessage
	}
	return []byte(t.Message)
}

// TraceContext 支持外部传入caller并将traceID注入
func (t *Task) TraceContext(f func(ctx context.Context, s string) context.Context) context.Context {
	return f(t.Ctx, t.TraceID)
}
