package log

import (
	"github.com/sirupsen/logrus"
	"os"
)

type DefaultLogger struct {
	ins *logrus.Logger
}

func (dl *DefaultLogger) Debug(v ...interface{}) {
	dl.ins.Debug(v...)
}

func (dl *DefaultLogger) Info(v ...interface{}) {
	dl.ins.Info(v...)
}

func (dl *DefaultLogger) Warn(v ...interface{}) {
	dl.ins.Warn(v...)
}

func (dl *DefaultLogger) Error(v ...interface{}) {
	dl.ins.Error(v...)
}

func GetDefaultLogger() Logger {
	logger := &DefaultLogger{}
	logger.ins = logrus.New()
	logger.ins.SetFormatter(&logrus.JSONFormatter{})
	logger.ins.SetOutput(os.Stdout)
	return logger
}
