package log

const (
	Debug = iota
	Info
	Warn
	Error
)

type Logger interface {
	Debug(v ...interface{})
	Info(v ...interface{})
	Warn(v ...interface{})
	Error(v ...interface{})
}


