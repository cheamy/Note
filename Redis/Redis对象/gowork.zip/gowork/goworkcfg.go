package gowork

import (
	"errors"
	"fmt"
	"time"

	"git.woa.com/templegu/gowork/log"
	"git.woa.com/templegu/gowork/queue"
)

// SetOptSleepy 设置休眠时间
func (w *Work) SetOptSleepy(t time.Duration) (bool, error) {
	w.opts.sleepy = t
	return true, nil
}

// SetOptTimer 设置超时时间
func (w *Work) SetOptTimer(t time.Duration) (bool, error) {
	w.opts.timer = t
	return true, nil
}

// SetOptDefaultConcurrency 设置 worker 的默认并发量，控制各 handler 最高运行个数
func (w *Work) SetOptDefaultConcurrency(dc int) (bool, error) {
	if dc < 0 {
		return false, errors.New("concurrency must be a positive integer")
	}

	w.opts.defaultConcurrency = dc
	return true, nil

}

// SetOptLogErrLv 设置运行时日志记录最低等级
func (w *Work) SetOptLogErrLv(el int) (bool, error) {
	if el > log.Error || el < log.Debug {
		return false, errors.New("errLevel should be between Debug and Error")
	}
	w.logErr = el
	return true, nil
}

// QueueDriverRegister queue 驱动注册
func (w *Work) QueueDriverRegister(queue queue.Queue) (bool, error) {
	if w.queueDriver != nil {
		return false, errors.New("Do not set the driver repeatedly ")
	}
	w.queueLock.Lock()
	w.queueDriver = queue
	w.queueLock.Unlock()
	return true, nil
}

// QueueDriverRegisterAlias queue 驱动别名注册
func (w *Work) QueueDriverRegisterAlias(name string, args ...interface{}) (bool, error) {
	if w.queueDriver != nil {
		return false, errors.New("Do not set the driver repeatedly ")
	}
	switch name {
	case "redis", "REDIS":
		if len(args) > 0 {
			conf := args[0]
			if rc, ok := conf.(queue.RedisConf); ok {
				q := queue.GetRedisQueue(rc)
				w.queueDriver = q
				break
			}
		}
		return false, errors.New("driver config error! ")
	case "kafka", "KAFKA":
		if len(args) > 0 {
			conf := args[0]
			if kc, ok := conf.(queue.KafkaConf); ok {
				q := queue.GetKafkaQueue(kc)
				w.queueDriver = q
				break
			}
		}
		w.queueDriver = new(queue.KafkaQueue)
	case "local", "LOCAL":
		w.queueDriver = new(queue.LocalQueue)
	case "pulsar", "Pulsar", "PULSAR":
		if len(args) > 0 {
			conf := args[0]
			if pc, ok := conf.(queue.PulsarConf); ok {
				q, err := queue.GetPulsarQueue(pc)
				if err != nil {
					return false, err
				}
				w.queueDriver = q
				break
			}
		}
		return false, errors.New("driver config error! ")
	default:
		return false, errors.New("no such driver yet ")
	}

	fmt.Println("current queue driver: " + name)
	return true, nil
}

// SetLogger 设置 log.Logger
func (w *Work) SetLogger(logger log.Logger) error {
	if w.rt.running {
		err := errors.New("please stop the worker! ")
		w.Log(log.Debug, err)
		return err
	}
	w.logger = logger
	return nil
}
